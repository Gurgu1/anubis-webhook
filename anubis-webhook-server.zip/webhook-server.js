const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post("/webhook", (req, res) => {
  console.log("✅ Webhook primit:", req.body);
  res.status(200).send("Webhook primit!");
});

app.get("/", (req, res) => {
  res.send("Serverul webhook este online 🚀");
});

app.listen(PORT, () => {
  console.log(`Serverul rulează pe portul ${PORT}`);
});